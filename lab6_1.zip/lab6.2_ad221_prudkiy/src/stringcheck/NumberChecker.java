
package stringcheck;
public class NumberChecker implements CheckString {
    @Override
    public boolean check(String str) {
        if (str.length() > 1 && str.charAt(0) == '0') {
            return false; // Первая цифра не может быть 0
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false; // Недопустимый символ
            }
        }
        return true; // Все символы - цифры
    }
}
