package stringcheck.impl;

import stringcheck.CheckString;

public class BracketChecker implements CheckString {
    @Override
    public boolean check(String str) {
        int balance = 0;
        for (char c : str.toCharArray()) {
            if (c == '(') {
                balance++;
            } else if (c == ')') {
                balance--;
            } else {
                return false; // Недопустимый символ
            }
            if (balance < 0) {
                return false; // Закрывающая скобка перед открывающей
            }
        }
        return balance == 0; // Если баланс равен 0, скобки сбалансированы
    }
}

