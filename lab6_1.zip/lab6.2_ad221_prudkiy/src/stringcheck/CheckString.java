package stringcheck;

public interface CheckString {
    boolean check(String str);
}
