package stringcheck;
import stringcheck.impl.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите строку для проверки:");
        String input = scanner.nextLine();

        BracketChecker bracketChecker = new BracketChecker();
        NumberChecker numberChecker = new NumberChecker();

        System.out.println("Проверка на правильность скобочной последовательности: " + bracketChecker.check(input));
        System.out.println("Проверка на правильность записи числа: " + numberChecker.check(input));
    }
}